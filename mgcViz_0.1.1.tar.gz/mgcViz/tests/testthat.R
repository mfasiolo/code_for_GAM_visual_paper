library(testthat)
library(mgcViz)

test_check("mgcViz")
