#' @rdname plot.ptermInteraction
#' @export plot.ptermInteraction
#' @export
#' 
plot.multi.ptermInteraction <- function(x, ...){
  
  message("mgcViz does not know how to plot interactions. Returning NULL.")
  return( invisible(NULL) )
  
}